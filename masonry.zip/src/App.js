import React from 'react';
import Masonry from './components/Masonry';

function App() {
  let list = [
    {
      id: 0,
      src: null,
      title: "제목",
      contents: `내용1\n가나다라마바사아`
    }
  ];
  const imgId = [1011, 883, 64, 1074, 823, 92, 643];
  imgId.push(0);
  imgId.push(65);
  imgId.push(0);
  imgId.push(839);
  imgId.push(0);
  imgId.push(314);
  imgId.push(0);
  imgId.push(256);
  imgId.push(0);
  imgId.push(316);
  imgId.push(0);
  imgId.push(400);
  imgId.push(0);
  imgId.push(600);
  imgId.push(0);
  imgId.push(500);
  for (let i = 0; i < imgId.length; i++) {
    const ih = 200 + Math.floor(Math.random() * 10) * 15;
    if (imgId[i] === 0) {
      list.push({ id: i+1, src: null, title: `제목 ${i}`, contents: `내용\ncontents\nabcdefg\n${Math.random() * 100000000000000000}` });
    } else {
      list.push({ id: i+1, src: "https://unsplash.it/250/" + ih + "?image=" + imgId[i], title: imgId[i], contents: "" });
    }
  }
  list.push({
    id: 9999999,
    src: null,
    title: "제목",
    contents: "내용2"
  })
  const Title = ({ item }) => {
    const { src, title, contents } = item;
    return (
      <div className="title">
        {src ? 
          <img src={src} alt={src.split("?")[1]} />
        :
          <div className="card">
            <h4>{title}</h4>
            <p>{contents}</p>
          </div>
        }
      </div>
    );
  };
  return (
    <div className="masonry-container">
      <Masonry>
        {list.map((item) => {
          return <Title item={item} key={item.id} />;
        })}
      </Masonry>
    </div>
  );
}

export default App;
